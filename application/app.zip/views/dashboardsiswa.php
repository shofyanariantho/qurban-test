<?php 
if ($user['stslulus'] =='Y'){

	
	 if(substr($user['kelas'],0,2)=='12'){
	$status = '	<a href="#" class="btn btn-success btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                      <i class="fas fa-check"></i>
                    </span>
                    <span class="text">LULUS</span>
				  </a>';
	 }
	 else
	 {
		 $status = '	<a href="#" class="btn btn-success btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                      <i class="fas fa-check"></i>
                    </span>
                    <span class="text">NAIK KELAS</span>
				  </a>';

	 }
				  

}
elseif($user['stslulus'] =='T')
{
		$status = '<a href="#" class="btn btn-danger btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                     <i class="fas fa-times-circle"></i>
                    </span>
                    <span class="text">TINGGAL KELAS</span>
				  </a>';
				  
				 
}
else{
    $status = '<a href="#" class="btn btn-warning btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                     <i class="fas fa-exclamation-triangle"></i>
                    </span>
                    <span class="text">NAIK KELAS BERSYARAT</span>
				  </a>';


}


if ($user['stsbayar']=='Y'){
$raport = '<a href='. base_url("assets/berkas/".$user["fileupload"] ).' download class="btn btn-info btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                     <i class="fas fa-download"></i>
                    </span>
                    <span class="text">Download Raport</span>
				  </a>';
}
else
{
$raport= '<button onclick="popup()" class="btn btn-info btn-icon-split btn-sm">
                    <span class="icon text-white-50">
                     <i class="fas fa-download"></i>
                    </span>
                    <span class="text">Download Raport</span>
				  </button>';

}


?>

<div class="row">
    <div class="col-xl-12 col-lg-12">
        <div class="card shadow mb-4">
		
            <!-- Card Header - Dropdown -->
            <div class="card-header bg-info py-3 d-flex flex-row align-items-center justify-content-between">
                <h6 class="m-0 font-weight-bold text-white">RAPORT ONLINE </h6>
            </div>
			<div class="card border-left-info shadow h-100 py-2">
            <!-- Card Body -->
            <div class="card-body">

			
				<h3>SELAMAT DATANG</h3>
                <i><strong>Assalamu'alaikum Warohmatullahi Wabarokaatuh </strong></i>
				<br>
				<br>
				<a href="#" class="btn btn-info btn-icon-split ">
                    <span class="icon text-white-50">
                     <i class="fas fa-user"></i>
                    </span>
                    <span class="text"><?= $user['nama'] ?></span>
				  </a>
				<br>
				<br>
				<p style="text-align:justify;text-indent:0em;">Puji syukur kita panjatkan kehadirat Allah SWT atas seluruh limpahan rahmat yang telah kita terima satu diantaranya adalah hasil kelulusan yang pada hari ini peserta didik terima, atas nama PESANTREN AL-MA'TUQ kami menerangkan bahwa <strong><a href="#"><?= $user['nama'] ?></a></strong> dinyatakan <?= $status ?> . Bagi yang belum berhasil / tidak lulus, jangan berputus asa karena pada hakekatnya kegagalan adalah keberhasilan yang tertunda. 
				Bagi yang sudah dinyatakan lulus maka siapkan diri kalian untuk memasuki jenjang pendidikan yang lebih tinggi yang diinginkan, teruslah belajar dengan penuh semangat.
Akhirnya atas nama Pesantren Al-MA'TUQ menghaturkan permohonan maaf apabila selama memberikan layanan pendidikan masih terdapat kekurangan.</p>

<p style="text-align:justify;text-indent:0em;">Wassalamu'alaikum Warohmatullahi Wabarokaatuh.</p>

<?= $raport ?>
<br>
<br>
<p style="text-align:justify;text-indent:0em;">PESANTREN AL-MA`TUQ SUKABUMI</p>
            </div>
			</div>
        </div>
    </div>
</div>
