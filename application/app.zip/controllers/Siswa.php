<?php
defined('BASEPATH') or exit('No direct script access allowed');
	use PhpOffice\PhpSpreadsheet\Helper\Sample;
	use PhpOffice\PhpSpreadsheet\IOFactory;
	use PhpOffice\PhpSpreadsheet\Spreadsheet;
class Siswa extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        cek_login();
       

        $this->load->model('Admin_model', 'admin');
		$this->load->library('form_validation');
		
	}
    public function index()
    {
		$data['title'] = "Daftar Siswa";
		if(is_admin()){
			 $data['siswa'] = $this->admin->getSiswa();
		}
		else{

			$data['siswa'] = $this->admin->getSiswaKelas(userdata('id_kelas'));
		}

        $this->template->load('templates/dashboard', 'siswa/data', $data);
	}
	
	public function lihat($data)
    {
	
        $this->load->view('siswa/lihat', $data);
    }

    private function _validasi($mode,$id)
    {
		$this->form_validation->set_rules('nik', 'NIK', 'required|trim');
		$this->form_validation->set_rules('nama', 'Nama', 'required|trim');
		$this->form_validation->set_rules('kelas_id', 'Kelas', 'required');
		$this->form_validation->set_rules('id_jenjang', 'Jenjang', 'required');
		$this->form_validation->set_rules('tanggal', 'Tanggal', 'required');




	
        if ($mode == 'add') {
            $this->form_validation->set_rules('nik', 'Nik', 'required|trim|is_unique[siswa.nik]|alpha_numeric');
        } else {

		
            $db = $this->admin->get('siswa', ['id_siswa' => $id]);
			$nik = $this->input->post('nik', true);
			
			
			
			if ($db['nik']== $nik ){
				 $uniq_nik = '';
			}
			else
			{
				 $uniq_nik = '|is_unique[siswa.nik]';
			}
            $this->form_validation->set_rules('nik', 'NIK', 'required|trim|alpha_numeric' . $uniq_nik);

        }
    }

    public function add()
    {
        $this->_validasi('add','');

        if ($this->form_validation->run() == false) {
			$data['title'] = "Tambah Siswa";
		
			$data['kelas'] = $this->admin->getKelas();
			$data['jenjang'] = $this->admin->getJenjang();

            $this->template->load('templates/dashboard', 'siswa/add', $data);
        } else {
            $input = $this->input->post(null, true);
            $input_data = [
                'nik'              => $input['nik'],
				'nama'             => $input['nama'],
				'jenis_kelamin'    => $input['jenis_kelamin'],
				'tgl_lahir'        => $input['tanggal'],
				'id_kelas'         => $input['kelas_id'],
				'id_jenjang'       => $input['id_jenjang'],
            ];

            if ($this->admin->insert('siswa', $input_data)) {
                set_pesan('data berhasil disimpan.');
                redirect('siswa');
            } else {
                set_pesan('data gagal disimpan', false);
                redirect('siswa/add');
            }
        }
    }

    public function edit($getId)
    {
		$data['kelas'] = $this->admin->getKelas();
		$data['jenjang'] = $this->admin->getJenjang();


		$id = encode_php_tags($getId);
	
        $this->_validasi('edit',$getId);


        if ($this->form_validation->run() == false) {
            $data['title'] = "Edit Siswa";
            $data['user'] = $this->admin->get('siswa', ['id_siswa' => $id]);
            $this->template->load('templates/dashboard', 'siswa/edit', $data);
        } else {
		

            $input = $this->input->post(null, true);
            $input_data = [
				'nik'              => $input['nik'],
				'nama'             => $input['nama'],
				'jenis_kelamin'    => $input['jenis_kelamin'],
				'tgl_lahir'        => $input['tanggal'],
				'id_kelas'         => $input['kelas_id'],
				'id_jenjang'       => $input['id_jenjang'],
            ];

            if ($this->admin->update('siswa', 'id_siswa', $id, $input_data)) {
                set_pesan('data berhasil diubah.');
                redirect('siswa');
            } else {
                set_pesan('data gagal diubah.', false);
                redirect('siswa/edit/' . $id);
            }
        }
    }

    public function delete($getId)
    {
        $id = encode_php_tags($getId);
        if ($this->admin->delete('siswa', 'id_siswa', $id)) {
            set_pesan('data berhasil dihapus.');
        } else {
            set_pesan('data gagal dihapus.', false);
        }
        redirect('siswa');
	}

	public function output_json($data, $encode = true)
	{
        if($encode) $data = json_encode($data);
        $this->output->set_content_type('application/json')->set_output($data);
	}
	
	public function deleteall()
	{
		
		$chk = $this->input->post('checked', true);
        if(!$chk){
			$this->output_json(['status'=>false]);
		
			
        }else{
            if($this->admin->deletesemua('siswa', $chk, 'id_siswa')){
				$this->output_json(['status'=>true]);
				
            }
        }
	}

	public function aktif()
	{
		
		$chk = $this->input->post('checked', true);
        if(!$chk){
			$this->output_json(['status'=>false]);
		
			
        }else{
            if($this->admin->aktifkansemua('siswa', $chk, 'id_siswa')){
				$this->output_json(['status'=>true]);
				
			}
			
        }
	}

	public function nonaktifkan()
	{
		
		$chk = $this->input->post('checked', true);
        if(!$chk){
			$this->output_json(['status'=>false]);
		
			
        }else{
          if($this->admin->nonaktifkansemua('siswa', $chk, 'id_siswa')){
				$this->output_json(['status'=>true]);
				
            }
        }
	}

    public function toggle($getId,$toggle)
    {
        $id = encode_php_tags($getId);
		//$status = $this->admin->get('siswa', ['id_siswa' => $getId])['stslulus'];
		
	   

	   if ($toggle == 'Y') {
			$pesan = 'Siswa Naik Kelas';
		} 
		elseif ($toggle == 'T') {
			$pesan = 'Siswa Tidak Naik Kelas';
		} 
		else {
			$pesan = 'Siswa Naik Kelas Bersyarat';

		}

        if ($this->admin->update('siswa', 'id_siswa', $getId, ['stslulus' => $toggle])) {
            set_pesan($pesan);
        }
        redirect('siswa');
	}
	
public function ubahpassword($getId)
    {
        $this->form_validation->set_rules('password_baru', 'Password Baru', 'required|trim|min_length[3]|differs[password_lama]');
        $this->form_validation->set_rules('konfirmasi_password', 'Konfirmasi Password', 'matches[password_baru]');

		
        if ($this->form_validation->run() == false) {
			$data['user'] = $this->admin->get('user', ['id_user' => $getId]);
            $data['title'] = "Reset Password";
            $this->template->load('templates/dashboard', 'siswa/ubahpassword', $data);
        } else {
            $input = $this->input->post(null, true);
          
                $new_pass = ['password' => password_hash($input['password_baru'], PASSWORD_DEFAULT)];
                $query = $this->admin->update('siswa', 'id_siswa', $getId, $new_pass);

                if ($query) {
                    set_pesan('password berhasil diubah.');
                } else {
                    set_pesan('gagal ubah password', false);
                }
            
            redirect('siswa/ubahpassword/'.$getId);
        }
	}

	 public function setting()
    {
     
        $this->_config();

        if ($this->form_validation->run() == false) {
            $data['title'] = "Profile";
            $data['user'] = $this->user;
            $this->template->load('templates/dashboard', 'profile/setting', $data);
        } else {
            $input = $this->input->post(null, true);
            if (empty($_FILES['foto']['name'])) {
                $insert = $this->admin->update('user', 'id_user', $input['id_user'], $input);
                if ($insert) {
                    set_pesan('perubahan berhasil disimpan.');
                } else {
                    set_pesan('perubahan tidak disimpan.');
                }
                redirect('profile/setting');
            } else {
                if ($this->upload->do_upload('foto') == false) {
                    echo $this->upload->display_errors();
                    die;
                } else {
                    if (userdata('foto') != 'user.png') {
                        $old_image = FCPATH . 'assets/img/avatar/' . userdata('foto');
                        if (!unlink($old_image)) {
                            set_pesan('gagal hapus foto lama.');
                            redirect('profile/setting');
                        }
                    }

                    $input['foto'] = $this->upload->data('file_name');
                    $update = $this->admin->update('user', 'id_user', $input['id_user'], $input);
                    if ($update) {
                        set_pesan('perubahan berhasil disimpan.');
                    } else {
                        set_pesan('gagal menyimpan perubahan');
                    }
                    redirect('profile/setting');
                }
            }
        }
    }
	
	public function upload ($getId){

		$data['siswa'] = $this->admin->get('siswa', ['id_siswa' => $getId]);
		$data['title'] = "Upload";
		$this->template->load('templates/dashboard', 'siswa/upload', $data);

	}


	public function do_upload()
    {
	  
		$idkelas=$this->input->post('id_siswa');
		$nik = $this->input->post('nik');

		$config['upload_path'] = './assets/berkas/';
		$config['allowed_types'] = 'pdf';
		$config['max_size'] = 1024;
		$config['file_name'] =$nik;
		$config['overwrite'] = true;

		

		$this->load->library('upload', $config);

		if ($this->upload->do_upload('file_nya') == false) {
				$data['error_upload'] = array('error' => $this->upload->display_errors());
				set_pesan('File gagal Diupload'.$data['error_upload']['error'],false);
			} else 
			{
				
				$input['fileupload'] = $this->upload->data('file_name');
				$update = $this->admin->update('siswa', 'id_siswa', $idkelas, $input);
				if ($update) {
					set_pesan('File berhasil Diupload.');
				} else {
					set_pesan('File gagal Diupload'.$data['error_upload']['error'],false);
				}
		
			}
			redirect(base_url("siswa/upload/". $idkelas)); 
	
	  }

	public function download_berkas($namafile){		
		
		$path = file_get_contents(base_url('assets/siswa/').$namafile); // get file name
		force_download($namafile, $path);

	   
	}	

	public function toggleraport($getId)
    {
        $id =($getId);
        $status = $this->admin->get('siswa', ['id_siswa' => $id])['stsbayar'];
        $toggle = trim($status)=="Y" ? "T" : "Y"; //Jika user aktif maka nonaktifkan, begitu pula sebaliknya
        $pesan = trim($toggle) =="Y" ? ' diaktifkan.' : 'dinonaktifkan.';

        if ($this->admin->update('siswa', 'id_siswa', $id, ['stsbayar' => $toggle])) {
            set_pesan($pesan);
        }
        redirect('siswa');
	}


	public function import($import_data = null)
	{
	
		if ($import_data != null) $data['import'] = $import_data;

			$data['title'] = "Import Data Kupon";
			$data['kelas'] = $this->admin->getKelas();
			$data['jenjang'] = $this->admin->getJenjang();
            $this->template->load('templates/dashboard', 'siswa/import', $data);
	}

	public function preview()
	{
		$config['upload_path']		= './uploads/import/';
		$config['allowed_types']	= 'xls|xlsx|csv';
		$config['max_size']			= 2048;
		$config['encrypt_name']		= true;

		$this->load->library('upload', $config);

		

		if (!$this->upload->do_upload('upload_file')) {
			$error = $this->upload->display_errors();
			echo $error;
			die;
		} else {
			$file = $this->upload->data('full_path');
			$ext = $this->upload->data('file_ext');

			switch ($ext) {
				case '.xlsx':
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
					break;
				case '.xls':
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
					break;
				case '.csv':
					$reader = new \PhpOffice\PhpSpreadsheet\Reader\Csv();
					break;
				default:
					echo "unknown file ext";
					die;
			}

			$spreadsheet = $reader->load($file);
			$sheetData = $spreadsheet->getActiveSheet()->toArray();
			$data = [];
			for ($i = 1; $i < count($sheetData); $i++) {
				$data[] = [
					'nik' => $sheetData[$i][0],
					'nama' => $sheetData[$i][1],
					'tgl_lahir' => $sheetData[$i][2],
					'stslulus' => $sheetData[$i][3],
					'jenis_kelamin' => $sheetData[$i][4],
					'id_kelas' => $sheetData[$i][5],
					'jenjang' => $sheetData[$i][6],
					'fileupload' => $sheetData[$i][7]
				];
			}

			unlink($file);

			$this->import($data);
		}
	}

	public function do_import()
	{
		$input = json_decode($this->input->post('data', true));
		$data = [];
		foreach ($input as $d) {
			$data[] = [
				'nik' => $d->nik,
				'nama' => $d->nama,
				'tgl_lahir' => $d->tgl_lahir,
				'stslulus' => $d->stslulus,
				'jenis_kelamin' => $d->jenis_kelamin,
				'id_kelas' => $d->id_kelas,
				'id_jenjang' => $d->jenjang,
				'fileupload' => $d->fileupload,
			];
		}

		$save = $this->admin->import('siswa', $data, true);
		if ($save) {
			redirect('siswa');
		} else {
			redirect('siswa/import');
		}
	}
    

}
