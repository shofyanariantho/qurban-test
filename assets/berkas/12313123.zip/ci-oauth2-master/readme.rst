###################
OAuth2 in CodeIgniter
###################

Documentation: http://www.aditya-nursyahbani.net/2016/10/tutorial-oauth2-dengan-codeigniter.html
